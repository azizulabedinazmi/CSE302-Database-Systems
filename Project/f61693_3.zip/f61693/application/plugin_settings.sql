prompt --application/plugin_settings
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>35383432320216087641
,p_default_application_id=>61693
,p_default_id_offset=>38504247172144128264
,p_default_owner=>'WKSP_AZMI'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(38173105269985995368)
,p_plugin_type=>'DYNAMIC ACTION'
,p_plugin=>'NATIVE_OPEN_AI_ASSISTANT'
,p_version_scn=>15568339995037
,p_created_on=>wwv_flow_imp.dz('20240913094721Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094721Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(38173105529258995369)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_COLOR_PICKER'
,p_attribute_01=>'FULL'
,p_attribute_02=>'POPUP'
,p_version_scn=>15568339995047
,p_created_on=>wwv_flow_imp.dz('20240913094721Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094721Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(38173105884149995369)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_DATE_PICKER_APEX'
,p_attribute_01=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_02=>'VISIBLE'
,p_attribute_03=>'15'
,p_attribute_04=>'FOCUS'
,p_version_scn=>15568339995051
,p_created_on=>wwv_flow_imp.dz('20240913094721Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094721Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(38173106124084995369)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_GEOCODED_ADDRESS'
,p_attribute_01=>'RELAX_HOUSE_NUMBER'
,p_attribute_02=>'N'
,p_attribute_03=>'POPUP:ITEM'
,p_attribute_04=>'default'
,p_attribute_06=>'LIST'
,p_version_scn=>15568339995081
,p_created_on=>wwv_flow_imp.dz('20240913094721Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094721Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(38173106403126995370)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SELECT_MANY'
,p_attribute_01=>'separated'
,p_version_scn=>15568339995096
,p_created_on=>wwv_flow_imp.dz('20240913094721Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094721Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(38173106789339995370)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SINGLE_CHECKBOX'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_version_scn=>15568339995109
,p_created_on=>wwv_flow_imp.dz('20240913094721Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094721Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(38173107027357995370)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_STAR_RATING'
,p_attribute_01=>'fa-star'
,p_attribute_04=>'#VALUE#'
,p_version_scn=>15568339995116
,p_created_on=>wwv_flow_imp.dz('20240913094721Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094721Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(38173107357687995371)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_YES_NO'
,p_attribute_01=>'Y'
,p_attribute_03=>'N'
,p_attribute_05=>'SWITCH_CB'
,p_version_scn=>15568339995131
,p_created_on=>wwv_flow_imp.dz('20240913094721Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094721Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(38173107683910995371)
,p_plugin_type=>'PROCESS TYPE'
,p_plugin=>'NATIVE_GEOCODING'
,p_attribute_01=>'RELAX_HOUSE_NUMBER'
,p_version_scn=>15568339995152
,p_created_on=>wwv_flow_imp.dz('20240913094721Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094721Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(38173107949110995371)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'include_slider', 'Y')).to_clob
,p_version_scn=>15568339995163
,p_created_on=>wwv_flow_imp.dz('20240913094721Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094721Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(38173108225269995371)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_IR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'actions_menu_structure', 'IG')).to_clob
,p_version_scn=>15568339995181
,p_created_on=>wwv_flow_imp.dz('20240913094721Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094721Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(38173108671536995372)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_MAP_REGION'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_vector_tile_layers', 'Y')).to_clob
,p_version_scn=>15568339995192
,p_created_on=>wwv_flow_imp.dz('20240913094721Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094721Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(38173108973379995372)
,p_plugin_type=>'WEB SOURCE TYPE'
,p_plugin=>'NATIVE_ADFBC'
,p_version_scn=>15568339995199
,p_created_on=>wwv_flow_imp.dz('20240913094721Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094721Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp.component_end;
end;
/
