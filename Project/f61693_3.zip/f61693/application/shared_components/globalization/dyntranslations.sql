prompt --application/shared_components/globalization/dyntranslations
begin
--   Manifest
--     DYNAMIC TRANSLATIONS: 61693
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>35383432320216087641
,p_default_application_id=>61693
,p_default_id_offset=>38504247172144128264
,p_default_owner=>'WKSP_AZMI'
);
null;
wwv_flow_imp.component_end;
end;
/
