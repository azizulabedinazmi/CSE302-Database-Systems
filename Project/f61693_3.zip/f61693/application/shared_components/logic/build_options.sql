prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 61693
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>35383432320216087641
,p_default_application_id=>61693
,p_default_id_offset=>38504247172144128264
,p_default_owner=>'WKSP_AZMI'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(38173109210472995372)
,p_build_option_name=>'Commented Out'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>15568339995203
,p_created_on=>wwv_flow_imp.dz('20240913094721Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094721Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(38174203554667995604)
,p_build_option_name=>'Feature: Activity Reporting'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>15568340012299
,p_feature_identifier=>'APPLICATION_ACTIVITY_REPORTING'
,p_build_option_comment=>'Include numerous reports and charts on end user activity.'
,p_created_on=>wwv_flow_imp.dz('20240913094724Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094724Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(38174203692408995604)
,p_build_option_name=>'Feature: Feedback'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>15568340012386
,p_feature_identifier=>'APPLICATION_FEEDBACK'
,p_build_option_comment=>'Provide a mechanism for end users to post general comments back to the application administrators and developers.'
,p_created_on=>wwv_flow_imp.dz('20240913094724Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094724Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(38174204145751995604)
,p_build_option_name=>'Feature: About Page'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>15568340012469
,p_feature_identifier=>'APPLICATION_ABOUT_PAGE'
,p_build_option_comment=>'About this application page.'
,p_created_on=>wwv_flow_imp.dz('20240913094724Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094724Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(38174204225303995604)
,p_build_option_name=>'Feature: Theme Style Selection'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>15568340012525
,p_feature_identifier=>'APPLICATION_THEME_STYLE_SELECTION'
,p_build_option_comment=>'Allow administrators to select a default color scheme (theme style) for the application. Administrators can also choose to allow end users to choose their own theme style. '
,p_created_on=>wwv_flow_imp.dz('20240913094724Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094724Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp.component_end;
end;
/
