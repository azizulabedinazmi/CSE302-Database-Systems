prompt --application/shared_components/navigation/lists/page_navigation
begin
--   Manifest
--     LIST: Page Navigation
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>35383432320216087641
,p_default_application_id=>61693
,p_default_id_offset=>38504247172144128264
,p_default_owner=>'WKSP_AZMI'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(38174499361913000936)
,p_name=>'Page Navigation'
,p_list_status=>'PUBLIC'
,p_version_scn=>15573673513529
,p_created_on=>wwv_flow_imp.dz('20240913094817Z')
,p_updated_on=>wwv_flow_imp.dz('20240920161051Z')
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38174499750287000937)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Airlines'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-fighter-jet fa-3x fa-anim-spin fa-rotate-270 fa-lg'
,p_list_item_icon_attributes=>'fa-fighter-jet fa-3x fa-anim-spin fa-rotate-270 fa-lg'
,p_list_item_icon_alt_attribute=>'fa-fighter-jet fa-3x fa-anim-spin fa-rotate-270 fa-lg'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20240913094817Z')
,p_updated_on=>wwv_flow_imp.dz('20240913163255Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38174500135072000937)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Airports'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-paper-plane fa-2x fa-anim-flash fa-lg'
,p_list_item_icon_attributes=>'fa-paper-plane fa-2x fa-anim-flash fa-lg'
,p_list_item_icon_alt_attribute=>'fa-paper-plane fa-2x fa-anim-flash fa-lg'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20240913094817Z')
,p_updated_on=>wwv_flow_imp.dz('20240913165027Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38174500598728000937)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Flights'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plane fa-2x fa-anim-horizontal-shake fa-lg'
,p_list_item_icon_attributes=>'fa-plane fa-2x fa-anim-horizontal-shake fa-lg'
,p_list_item_icon_alt_attribute=>'fa-plane fa-2x fa-anim-horizontal-shake fa-lg'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20240913094817Z')
,p_updated_on=>wwv_flow_imp.dz('20240913165109Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38174500969009000937)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Passengers'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users fa-3x fa-anim-flash fa-lg'
,p_list_item_icon_attributes=>'fa-users fa-3x fa-anim-flash fa-lg'
,p_list_item_icon_alt_attribute=>'fa-users fa-3x fa-anim-flash fa-lg'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20240913094817Z')
,p_updated_on=>wwv_flow_imp.dz('20240913165156Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38174501338258000938)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Bookings'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bookmark fa-3x fa-anim-vertical-shake fa-lg'
,p_list_item_icon_attributes=>'fa-bookmark fa-3x fa-anim-vertical-shake fa-lg'
,p_list_item_icon_alt_attribute=>'fa-bookmark fa-3x fa-anim-vertical-shake fa-lg'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20240913094817Z')
,p_updated_on=>wwv_flow_imp.dz('20240913165312Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38174501761000000938)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Crew'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-male fa-3x fa-anim-horizontal-shake fa-lg'
,p_list_item_icon_attributes=>'fa-male fa-3x fa-anim-horizontal-shake fa-lg'
,p_list_item_icon_alt_attribute=>'fa-male fa-3x fa-anim-horizontal-shake fa-lg'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20240913094817Z')
,p_updated_on=>wwv_flow_imp.dz('20240913165354Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38174502101799000938)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Flight Crew'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-woman fa-3x fa-anim-vertical-shake fa-lg'
,p_list_item_icon_attributes=>'fa-user-woman fa-3x fa-anim-vertical-shake fa-lg'
,p_list_item_icon_alt_attribute=>'fa-user-woman fa-3x fa-anim-vertical-shake fa-lg'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20240913094817Z')
,p_updated_on=>wwv_flow_imp.dz('20240913170600Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38174502548561000938)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Payments'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-credit-card fa-3x fa-anim-flash fa-lg'
,p_list_item_icon_attributes=>'fa-credit-card fa-3x fa-anim-flash fa-lg'
,p_list_item_icon_alt_attribute=>'fa-credit-card fa-3x fa-anim-flash fa-lg'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20240913094817Z')
,p_updated_on=>wwv_flow_imp.dz('20240913170639Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38174502960240000939)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Flight Status'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-paper-plane-o fa-3x fa-anim-horizontal-shake fa-lg'
,p_list_item_icon_attributes=>'fa-paper-plane-o fa-3x fa-anim-horizontal-shake fa-lg'
,p_list_item_icon_alt_attribute=>'fa-paper-plane-o fa-3x fa-anim-horizontal-shake fa-lg'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20240913094817Z')
,p_updated_on=>wwv_flow_imp.dz('20240913171229Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38174503347437000939)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Financial Transactions'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-exchange fa-3x fa-anim-spin fa-lg'
,p_list_item_icon_attributes=>'fa-exchange fa-3x fa-anim-spin fa-lg'
,p_list_item_icon_alt_attribute=>'fa-exchange fa-3x fa-anim-spin fa-lg'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20240913094817Z')
,p_updated_on=>wwv_flow_imp.dz('20240913171334Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(38174503748060000939)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Users'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users-alt fa-3x fa-anim-flash fam-heart fam-is-success fa-lg'
,p_list_item_icon_attributes=>'fa-users-alt fa-3x fa-anim-flash fam-heart fam-is-success fa-lg'
,p_list_item_icon_alt_attribute=>'fa-users-alt fa-3x fa-anim-flash fam-heart fam-is-success fa-lg'
,p_security_scheme=>wwv_flow_imp.id(3790763255183295772)
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20240913094817Z')
,p_updated_on=>wwv_flow_imp.dz('20240920161051Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp.component_end;
end;
/
