prompt --application/shared_components/user_interface/lovs/bookings_seat_class
begin
--   Manifest
--     BOOKINGS.SEAT_CLASS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>35383432320216087641
,p_default_application_id=>61693
,p_default_id_offset=>38504247172144128264
,p_default_owner=>'WKSP_AZMI'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38174346147775999329)
,p_lov_name=>'BOOKINGS.SEAT_CLASS'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'BOOKINGS'
,p_return_column_name=>'BOOKING_ID'
,p_display_column_name=>'SEAT_CLASS'
,p_default_sort_column_name=>'SEAT_CLASS'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15568340336812
,p_created_on=>wwv_flow_imp.dz('20240913094801Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094801Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp.component_end;
end;
/
