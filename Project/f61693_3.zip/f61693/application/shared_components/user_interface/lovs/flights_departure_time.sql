prompt --application/shared_components/user_interface/lovs/flights_departure_time
begin
--   Manifest
--     FLIGHTS.DEPARTURE_TIME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>35383432320216087641
,p_default_application_id=>61693
,p_default_id_offset=>38504247172144128264
,p_default_owner=>'WKSP_AZMI'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38252775097921924955)
,p_lov_name=>'FLIGHTS.DEPARTURE_TIME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'FLIGHTS'
,p_return_column_name=>'FLIGHT_ID'
,p_display_column_name=>'DEPARTURE_TIME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'DEPARTURE_TIME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15570675589374
,p_created_on=>wwv_flow_imp.dz('20240913122217Z')
,p_updated_on=>wwv_flow_imp.dz('20240916160509Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp.component_end;
end;
/
