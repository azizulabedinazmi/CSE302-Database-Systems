prompt --application/shared_components/security/authorizations/admin
begin
--   Manifest
--     SECURITY SCHEME: admin
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>35383432320216087641
,p_default_application_id=>61693
,p_default_id_offset=>38504247172144128264
,p_default_owner=>'WKSP_AZMI'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(38183080113829797202)
,p_name=>'admin'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT user_roll ',
'FROM users ',
'WHERE upper(user_name) = upper(V(''APP_USER'')) ',
'AND user_roll IN (''admin'');'))
,p_version_scn=>15568560659250
,p_caching=>'BY_USER_BY_SESSION'
,p_created_on=>wwv_flow_imp.dz('20240913100438Z')
,p_updated_on=>wwv_flow_imp.dz('20240913172027Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp.component_end;
end;
/
