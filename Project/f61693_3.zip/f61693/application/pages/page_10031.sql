prompt --application/pages/page_10031
begin
--   Manifest
--     PAGE: 10031
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>35383432320216087641
,p_default_application_id=>61693
,p_default_id_offset=>38504247172144128264
,p_default_owner=>'WKSP_AZMI'
);
wwv_flow_imp_page.create_page(
 p_id=>10031
,p_name=>'Feedback Submitted'
,p_alias=>'FEEDBACK-SUBMITTED'
,p_page_mode=>'MODAL'
,p_step_title=>'Feedback Submitted'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(38174205938266995607)
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(38174203692408995604)
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_created_on=>wwv_flow_imp.dz('20240913094823Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240913094823Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_last_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38174594034047001544)
,p_plug_name=>'Feedback Submitted'
,p_icon_css_classes=>'fa-check-circle'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--success'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38173141698734995399)
,p_plug_display_sequence=>10
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240913094823Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094823Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38174593939308001544)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(38174594034047001544)
,p_button_name=>'CLOSE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38174087516425995477)
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_css_classes=>'w40p'
,p_created_on=>wwv_flow_imp.dz('20240913094823Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094823Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38174594181719001544)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38174593939308001544)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20240913094823Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094823Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38174605955594001552)
,p_event_id=>wwv_flow_imp.id(38174594181719001544)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
,p_created_on=>wwv_flow_imp.dz('20240913094823Z')
,p_updated_on=>wwv_flow_imp.dz('20240913094823Z')
,p_created_by=>'AZMI00121@GMAIL.COM'
,p_updated_by=>'AZMI00121@GMAIL.COM'
);
wwv_flow_imp.component_end;
end;
/
